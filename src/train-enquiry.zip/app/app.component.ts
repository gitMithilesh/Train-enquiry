import { Component } from '@angular/core';
import { Http } from '@angular/http';
// import './node_modules/rxjs/add/operator/map';
import { StatusService } from './status.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

}
